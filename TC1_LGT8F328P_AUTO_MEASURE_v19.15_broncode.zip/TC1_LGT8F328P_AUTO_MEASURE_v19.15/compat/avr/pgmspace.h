#ifndef AVR_PGMSPACE_H
#define AVR_PGMSPACE_H
#include <stdint.h>
#include <stddef.h>

/* Keep constants in program flash.  LGT8F328P uses the AVR Harvard memory model,
 * so program-memory reads must use LPM rather than ordinary SRAM loads. */
#define PROGMEM __attribute__((section(".progmem.data")))
#define PGM_P const char *
#define PSTR(s) (s)

static inline uint8_t __tc1_pgm_read_byte(const void *addr)
{
  uint8_t value;
  const uint8_t *p = (const uint8_t *)addr;
  __asm__ __volatile__("lpm %0, Z" : "=r"(value) : "z"(p));
  return value;
}

static inline uint16_t __tc1_pgm_read_word(const void *addr)
{
  uintptr_t p = (uintptr_t)addr;
  uint16_t v = __tc1_pgm_read_byte((const void *)p);
  v |= (uint16_t)__tc1_pgm_read_byte((const void *)(p + 1)) << 8;
  return v;
}

static inline uint32_t __tc1_pgm_read_dword(const void *addr)
{
  uintptr_t p = (uintptr_t)addr;
  uint32_t v = __tc1_pgm_read_byte((const void *)p);
  v |= (uint32_t)__tc1_pgm_read_byte((const void *)(p + 1)) << 8;
  v |= (uint32_t)__tc1_pgm_read_byte((const void *)(p + 2)) << 16;
  v |= (uint32_t)__tc1_pgm_read_byte((const void *)(p + 3)) << 24;
  return v;
}

#define pgm_read_byte(addr)  __tc1_pgm_read_byte((const void *)(addr))
#define pgm_read_word(addr)  __tc1_pgm_read_word((const void *)(addr))
#define pgm_read_dword(addr) __tc1_pgm_read_dword((const void *)(addr))
#define pgm_read_ptr(addr)   ((void *)(uintptr_t)__tc1_pgm_read_word((const void *)(addr)))

#endif
