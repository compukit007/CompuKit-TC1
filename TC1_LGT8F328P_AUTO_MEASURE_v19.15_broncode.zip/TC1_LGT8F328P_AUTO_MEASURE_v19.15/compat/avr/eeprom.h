#ifndef AVR_EEPROM_H
#define AVR_EEPROM_H
#include <stdint.h>
#include <stddef.h>
#define EEMEM __attribute__((section(".eeprom")))
uint8_t eeprom_read_byte(const uint8_t *p);
uint16_t eeprom_read_word(const uint16_t *p);
void eeprom_read_block(void *dst,const void *src,size_t n);
void eeprom_write_byte(uint8_t *p,uint8_t v);
void eeprom_write_word(uint16_t *p,uint16_t v);
void eeprom_write_block(const void *src,void *dst,size_t n);
#endif
