#ifndef AVR_SLEEP_H
#define AVR_SLEEP_H
#include <stdint.h>
#define SLEEP_MODE_IDLE 0
#define SLEEP_MODE_PWR_DOWN 2
#define SLEEP_MODE_PWR_SAVE 3
static inline void set_sleep_mode(uint8_t m){ (void)m; }
static inline void sleep_enable(void){}
static inline void sleep_disable(void){}
static inline void sleep_cpu(void){__asm__ __volatile__("sleep");}
static inline void sleep_mode(void){sleep_cpu();}
#endif
