#ifndef AVR_INTERRUPT_H
#define AVR_INTERRUPT_H
#define sei() __asm__ __volatile__("sei" ::: "memory")
#define cli() __asm__ __volatile__("cli" ::: "memory")
#define ISR(vector, ...) void vector(void) __attribute__((signal,used,externally_visible)); void vector(void)
#define ISR_NAKED __attribute__((naked))
#define TIMER0_COMPA_vect __vector_14
#define TIMER0_COMPB_vect __vector_15
#define TIMER0_OVF_vect __vector_16
#define TIMER1_CAPT_vect __vector_10
#define TIMER1_COMPA_vect __vector_11
#define TIMER1_COMPB_vect __vector_12
#define TIMER1_OVF_vect __vector_13
#define TIMER2_COMPA_vect __vector_7
#define TIMER2_COMPB_vect __vector_8
#define TIMER2_OVF_vect __vector_9
#define PCINT0_vect __vector_3
#define PCINT1_vect __vector_4
#define PCINT2_vect __vector_5
#define INT0_vect __vector_1
#define INT1_vect __vector_2
#endif
