#ifndef _STDLIB_H
#define _STDLIB_H
#include <stddef.h>
char *utoa(unsigned int v,char *s,int radix);
char *ultoa(unsigned long v,char *s,int radix);
#ifndef abs
#define abs(x) ((x)<0?-(x):(x))
#endif
#endif
