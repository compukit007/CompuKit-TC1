#ifndef UTIL_DELAY_H
#define UTIL_DELAY_H
static inline void _delay_us(double us){ (void)us; }
static inline void _delay_ms(double ms){ (void)ms; }
#endif
