#ifndef _MATH_H
#define _MATH_H
double sqrt(double); double log(double); double floor(double); double round(double);
#endif
