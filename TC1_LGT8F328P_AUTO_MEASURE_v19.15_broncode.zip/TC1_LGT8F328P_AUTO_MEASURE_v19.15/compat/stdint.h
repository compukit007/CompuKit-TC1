#ifndef _STDINT_H
#define _STDINT_H
typedef signed char int8_t; typedef unsigned char uint8_t;
typedef signed short int16_t; typedef unsigned short uint16_t;
typedef signed long int32_t; typedef unsigned long uint32_t;
typedef signed long long int64_t; typedef unsigned long long uint64_t;
typedef int16_t intptr_t; typedef uint16_t uintptr_t;
typedef int8_t int_least8_t; typedef uint8_t uint_least8_t; typedef int16_t int_least16_t; typedef uint16_t uint_least16_t; typedef int32_t int_least32_t; typedef uint32_t uint_least32_t;
typedef int8_t int_fast8_t; typedef uint8_t uint_fast8_t; typedef int16_t int_fast16_t; typedef uint16_t uint_fast16_t; typedef int32_t int_fast32_t; typedef uint32_t uint_fast32_t;
#define UINT8_MAX 255U
#define UINT16_MAX 65535U
#define INT16_MAX 32767
#define UINT32_MAX 4294967295UL
#endif
