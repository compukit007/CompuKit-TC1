#ifndef _STRING_H
#define _STRING_H
#include <stddef.h>
size_t strlen(const char *s);
void *memcpy(void *d,const void *s,size_t n);
void *memset(void *d,int c,size_t n);
char *strcpy(char *d,const char *s);
#endif
