#ifndef STDFIX_H
#define STDFIX_H
#endif
