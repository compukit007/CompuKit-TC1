#include <stdint.h>
#define CYC_US(us) ((unsigned long)(16UL*(us)))
#define CYC_MS(ms) ((unsigned long)(16000UL*(ms)))
#define DEF_US(n) void wait##n##us(void){ __builtin_avr_delay_cycles(CYC_US(n)); }
#define DEF_MS(n) void wait##n##ms(void){ __builtin_avr_delay_cycles(CYC_MS(n)); }
DEF_US(1) DEF_US(2) DEF_US(3) DEF_US(4) DEF_US(5) DEF_US(10) DEF_US(20) DEF_US(30) DEF_US(40) DEF_US(50) DEF_US(100) DEF_US(200) DEF_US(300) DEF_US(400) DEF_US(500)
DEF_MS(1) DEF_MS(2) DEF_MS(3) DEF_MS(4) DEF_MS(5) DEF_MS(10) DEF_MS(20) DEF_MS(30) DEF_MS(40) DEF_MS(50) DEF_MS(100) DEF_MS(200) DEF_MS(300) DEF_MS(400) DEF_MS(500) DEF_MS(1000)
void wait1s(void){wait1000ms();}
void wait2s(void){wait1000ms();wait1000ms();}
void wait3s(void){wait2s();wait1000ms();}
void wait4s(void){wait2s();wait2s();}
void wait5s(void){wait4s();wait1000ms();}
