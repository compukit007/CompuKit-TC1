/* ************************************************************************
 *
 *   TC1 user interface strings (Compukit)
 *   - Dutch (default), English (TC1_LANG_EN), Russian (TC1_LANG_RU)
 *   - Russian: Windows-1251, written as octal escapes
 *   - generated, include only once (tc1_ui.c)
 *
 * ************************************************************************ */

#if defined (TC1_LANG_EN)
  const unsigned char TC1_TxtTesting[] PROGMEM = "Testing...";   /* Testing... */
  const unsigned char TC1_TxtVbat[] PROGMEM = "Vbat=";   /* Vbat= */
  const unsigned char TC1_TxtNoBat[] PROGMEM = "no battery";   /* no battery */
  const unsigned char TC1_TxtDiode[] PROGMEM = "Diode";   /* Diode */
  const unsigned char TC1_TxtCap[] PROGMEM = "Capacitor";   /* Capacitor */
  const unsigned char TC1_TxtRes[] PROGMEM = "Resistor";   /* Resistor */
  const unsigned char TC1_Txt2Res[] PROGMEM = "2 resistors";   /* 2 resistors */
  const unsigned char TC1_TxtCoil[] PROGMEM = "Inductor";   /* Inductor */
  const unsigned char TC1_TxtESR[] PROGMEM = "ESR=";   /* ESR= */
  const unsigned char TC1_TxtLeak[] PROGMEM = "Ileak=";   /* Ileak= */
  const unsigned char TC1_TxtNo1[] PROGMEM = "Unknown or";   /* Unknown or */
  const unsigned char TC1_TxtNo2[] PROGMEM = "damaged part";   /* damaged part */
  const unsigned char TC1_TxtIR[] PROGMEM = "IR decoder";   /* IR decoder */
  const unsigned char TC1_TxtUser[] PROGMEM = "UserCode";   /* UserCode */
  const unsigned char TC1_TxtData[] PROGMEM = "DataCode";   /* DataCode */
  const unsigned char TC1_TxtSamsung[] PROGMEM = "Samsung";   /* Samsung */
  const unsigned char TC1_TxtNEC[] PROGMEM = "NEC";   /* NEC */
  const unsigned char TC1_TxtShort1[] PROGMEM = "Connect pins";   /* Connect pins */
  const unsigned char TC1_TxtShort2[] PROGMEM = "1, 2 and 3";   /* 1, 2 and 3 */
  const unsigned char TC1_TxtOpen1[] PROGMEM = "Remove the";   /* Remove the */
  const unsigned char TC1_TxtOpen2[] PROGMEM = "connection";   /* connection */
  const unsigned char TC1_TxtZener[] PROGMEM = "Zener test";   /* Zener test */
  const unsigned char TC1_TxtZenerHint[] PROGMEM = "2x short=back";   /* 2x short=back */
  const unsigned char TC1_TxtESRTitle[] PROGMEM = "ESR meter";   /* ESR meter */
  const unsigned char TC1_TxtESRWarn1[] PROGMEM = "Power off and";   /* Power off and */
  const unsigned char TC1_TxtESRWarn2[] PROGMEM = "discharge the";   /* discharge the */
  const unsigned char TC1_TxtESRWarn3[] PROGMEM = "capacitor first";   /* capacitor first */
  const unsigned char TC1_TxtESRPins[] PROGMEM = "pin1=+  pin3=-";   /* pin1=+  pin3=- */
  const unsigned char TC1_TxtVoltage[] PROGMEM = "Voltage!";   /* Voltage! */
  const unsigned char TC1_TxtMenu1[] PROGMEM = "Calibration";   /* Calibration */
  const unsigned char TC1_TxtMenu2[] PROGMEM = "Zener test";   /* Zener test */
  const unsigned char TC1_TxtMenu3[] PROGMEM = "ESR meter";   /* ESR meter */
  const unsigned char TC1_TxtMenu4[] PROGMEM = "Opto test";   /* Opto test */
  const unsigned char TC1_TxtMenu5[] PROGMEM = "Power off";   /* Power off */
  const unsigned char TC1_TxtMenu6[] PROGMEM = "Back";   /* Back */
  const unsigned char TC1_TxtHint1[] PROGMEM = "long = select";   /* long = select */
  const unsigned char TC1_TxtName[] PROGMEM = "Compukit";   /* Compukit */
  const unsigned char TC1_TxtBase[] PROGMEM = "m-firmware 1.42";   /* m-firmware 1.42 */
  const unsigned char TC1_TxtAuthor[] PROGMEM = "by M. Reschke";   /* by M. Reschke */
  const unsigned char TC1_TxtStartHint[] PROGMEM = "1x short=start";   /* 1x short=start */
#elif defined (TC1_LANG_RU)
  const unsigned char TC1_TxtTesting[] PROGMEM = "\322\345\361\362...";   /* ru: 0 */
  const unsigned char TC1_TxtVbat[] PROGMEM = "Vbat=";   /* ru: 1 */
  const unsigned char TC1_TxtNoBat[] PROGMEM = "\355\345\362 \341\340\362\340\360\345\350";   /* ru: 2 */
  const unsigned char TC1_TxtDiode[] PROGMEM = "\304\350\356\344";   /* ru: 3 */
  const unsigned char TC1_TxtCap[] PROGMEM = "\312\356\355\344\345\355\361\340\362\356\360";   /* ru: 4 */
  const unsigned char TC1_TxtRes[] PROGMEM = "\320\345\347\350\361\362\356\360";   /* ru: 5 */
  const unsigned char TC1_Txt2Res[] PROGMEM = "2 \360\345\347\350\361\362\356\360\340";   /* ru: 6 */
  const unsigned char TC1_TxtCoil[] PROGMEM = "\312\340\362\363\370\352\340";   /* ru: 7 */
  const unsigned char TC1_TxtESR[] PROGMEM = "ESR=";   /* ru: 8 */
  const unsigned char TC1_TxtLeak[] PROGMEM = "I\363\362=";   /* ru: 9 */
  const unsigned char TC1_TxtNo1[] PROGMEM = "\315\345\350\347\342\345\361\362\355\340\377 \350\353\350";   /* ru: 10 */
  const unsigned char TC1_TxtNo2[] PROGMEM = "\355\345\350\361\357\360\340\342\355\340\377 \344\345\362\340\353\374";   /* ru: 11 */
  const unsigned char TC1_TxtIR[] PROGMEM = "\310\312-\344\345\352\356\344\345\360";   /* ru: 12 */
  const unsigned char TC1_TxtUser[] PROGMEM = "\300\344\360\345\361";   /* ru: 13 */
  const unsigned char TC1_TxtData[] PROGMEM = "\312\356\354\340\355\344\340";   /* ru: 14 */
  const unsigned char TC1_TxtSamsung[] PROGMEM = "Samsung";   /* ru: 15 */
  const unsigned char TC1_TxtNEC[] PROGMEM = "NEC";   /* ru: 16 */
  const unsigned char TC1_TxtShort1[] PROGMEM = "\321\356\345\344\350\355\350\362\345 \342\373\342\356\344\373";   /* ru: 17 */
  const unsigned char TC1_TxtShort2[] PROGMEM = "1, 2 \350 3";   /* ru: 18 */
  const unsigned char TC1_TxtOpen1[] PROGMEM = "\323\341\345\360\350\362\345";   /* ru: 19 */
  const unsigned char TC1_TxtOpen2[] PROGMEM = "\357\345\360\345\354\373\367\352\363";   /* ru: 20 */
  const unsigned char TC1_TxtZener[] PROGMEM = "\321\362\340\341\350\353\350\362\360\356\355";   /* ru: 21 */
  const unsigned char TC1_TxtZenerHint[] PROGMEM = "2x \352\360\340\362\352\356=\355\340\347\340\344";   /* ru: 22 */
  const unsigned char TC1_TxtESRTitle[] PROGMEM = "\310\347\354\345\360\345\355\350\345 ESR";   /* ru: 23 */
  const unsigned char TC1_TxtESRWarn1[] PROGMEM = "\302\373\352\353\376\367\350\362\345 \357\353\340\362\363";   /* ru: 24 */
  const unsigned char TC1_TxtESRWarn2[] PROGMEM = "\350 \360\340\347\360\377\344\350\362\345";   /* ru: 25 */
  const unsigned char TC1_TxtESRWarn3[] PROGMEM = "\352\356\355\344\345\355\361\340\362\356\360!";   /* ru: 26 */
  const unsigned char TC1_TxtESRPins[] PROGMEM = "pin1=+  pin3=-";   /* ru: 27 */
  const unsigned char TC1_TxtVoltage[] PROGMEM = "\315\340\357\360\377\346\345\355\350\345!";   /* ru: 28 */
  const unsigned char TC1_TxtMenu1[] PROGMEM = "\312\340\353\350\341\360\356\342\352\340";   /* ru: 29 */
  const unsigned char TC1_TxtMenu2[] PROGMEM = "\321\362\340\341\350\353\350\362\360\356\355";   /* ru: 30 */
  const unsigned char TC1_TxtMenu3[] PROGMEM = "\310\347\354\345\360\345\355\350\345 ESR";   /* ru: 31 */
  const unsigned char TC1_TxtMenu4[] PROGMEM = "\316\357\362\356\357\340\360\340";   /* ru: 32 */
  const unsigned char TC1_TxtMenu5[] PROGMEM = "\302\373\352\353\376\367\350\362\374";   /* ru: 33 */
  const unsigned char TC1_TxtMenu6[] PROGMEM = "\315\340\347\340\344";   /* ru: 34 */
  const unsigned char TC1_TxtHint1[] PROGMEM = "\344\356\353\343\356 = \342\373\341\356\360";   /* ru: 35 */
  const unsigned char TC1_TxtName[] PROGMEM = "Compukit";   /* ru: 36 */
  const unsigned char TC1_TxtBase[] PROGMEM = "m-firmware 1.42";   /* ru: 37 */
  const unsigned char TC1_TxtAuthor[] PROGMEM = "\340\342\362\356\360 M. Reschke";   /* ru: 38 */
  const unsigned char TC1_TxtStartHint[] PROGMEM = "1x \352\360\340\362\352\356=\361\362\340\360\362";   /* ru: 39 */
#else
  const unsigned char TC1_TxtTesting[] PROGMEM = "Testen...";   /* Testen... */
  const unsigned char TC1_TxtVbat[] PROGMEM = "Vbat=";   /* Vbat= */
  const unsigned char TC1_TxtNoBat[] PROGMEM = "geen accu";   /* geen accu */
  const unsigned char TC1_TxtDiode[] PROGMEM = "Diode";   /* Diode */
  const unsigned char TC1_TxtCap[] PROGMEM = "Condensator";   /* Condensator */
  const unsigned char TC1_TxtRes[] PROGMEM = "Weerstand";   /* Weerstand */
  const unsigned char TC1_Txt2Res[] PROGMEM = "2 weerstanden";   /* 2 weerstanden */
  const unsigned char TC1_TxtCoil[] PROGMEM = "Spoel";   /* Spoel */
  const unsigned char TC1_TxtESR[] PROGMEM = "ESR=";   /* ESR= */
  const unsigned char TC1_TxtLeak[] PROGMEM = "Ilek=";   /* Ilek= */
  const unsigned char TC1_TxtNo1[] PROGMEM = "Onbekend of";   /* Onbekend of */
  const unsigned char TC1_TxtNo2[] PROGMEM = "defect onderdeel";   /* defect onderdeel */
  const unsigned char TC1_TxtIR[] PROGMEM = "IR-decoder";   /* IR-decoder */
  const unsigned char TC1_TxtUser[] PROGMEM = "Adres";   /* Adres */
  const unsigned char TC1_TxtData[] PROGMEM = "Commando";   /* Commando */
  const unsigned char TC1_TxtSamsung[] PROGMEM = "Samsung";   /* Samsung */
  const unsigned char TC1_TxtNEC[] PROGMEM = "NEC";   /* NEC */
  const unsigned char TC1_TxtShort1[] PROGMEM = "Verbind pin";   /* Verbind pin */
  const unsigned char TC1_TxtShort2[] PROGMEM = "1, 2 en 3";   /* 1, 2 en 3 */
  const unsigned char TC1_TxtOpen1[] PROGMEM = "Verwijder de";   /* Verwijder de */
  const unsigned char TC1_TxtOpen2[] PROGMEM = "verbinding";   /* verbinding */
  const unsigned char TC1_TxtZener[] PROGMEM = "Zenertest";   /* Zenertest */
  const unsigned char TC1_TxtZenerHint[] PROGMEM = "2x kort=terug";   /* 2x kort=terug */
  const unsigned char TC1_TxtESRTitle[] PROGMEM = "ESR-meting";   /* ESR-meting */
  const unsigned char TC1_TxtESRWarn1[] PROGMEM = "Print uit en";   /* Print uit en */
  const unsigned char TC1_TxtESRWarn2[] PROGMEM = "condensator";   /* condensator */
  const unsigned char TC1_TxtESRWarn3[] PROGMEM = "eerst ontladen!";   /* eerst ontladen! */
  const unsigned char TC1_TxtESRPins[] PROGMEM = "pin1=+  pin3=-";   /* pin1=+  pin3=- */
  const unsigned char TC1_TxtVoltage[] PROGMEM = "Spanning!";   /* Spanning! */
  const unsigned char TC1_TxtMenu1[] PROGMEM = "Kalibratie";   /* Kalibratie */
  const unsigned char TC1_TxtMenu2[] PROGMEM = "Zenertest";   /* Zenertest */
  const unsigned char TC1_TxtMenu3[] PROGMEM = "ESR-meting";   /* ESR-meting */
  const unsigned char TC1_TxtMenu4[] PROGMEM = "Opto-test";   /* Opto-test */
  const unsigned char TC1_TxtMenu5[] PROGMEM = "Uitzetten";   /* Uitzetten */
  const unsigned char TC1_TxtMenu6[] PROGMEM = "Terug";   /* Terug */
  const unsigned char TC1_TxtHint1[] PROGMEM = "lang = kiezen";   /* lang = kiezen */
  const unsigned char TC1_TxtName[] PROGMEM = "Compukit";   /* Compukit */
  const unsigned char TC1_TxtBase[] PROGMEM = "m-firmware 1.42";   /* m-firmware 1.42 */
  const unsigned char TC1_TxtAuthor[] PROGMEM = "door M. Reschke";   /* door M. Reschke */
  const unsigned char TC1_TxtStartHint[] PROGMEM = "1x kort=start";   /* 1x kort=start */
#endif
