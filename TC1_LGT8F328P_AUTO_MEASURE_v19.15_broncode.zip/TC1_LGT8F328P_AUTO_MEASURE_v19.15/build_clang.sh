#!/bin/bash
set -euo pipefail
rm -rf obj_new
mkdir obj_new
CFLAGS=(--target=avr -mmcu=atmega328 -Oz -ffunction-sections -fdata-sections -fno-builtin -funsigned-char -Icompat -I. -Ibitmaps -D__LGT8FX8P__ -DF_CPU=16000000UL)
for f in *.c; do
  case "$f" in wait_compat.c|minilib.c) continue;; esac
  echo "CC $f"
  clang "${CFLAGS[@]}" -c "$f" -o "obj_new/${f%.c}.o"
done
clang "${CFLAGS[@]}" -c minilib.c -o obj_new/minilib.o
clang --target=avr -mmcu=atmega328 -Icompat -I. -Ibitmaps -D__LGT8FX8P__ -DF_CPU=16000000UL -c wait_clang.S -o obj_new/wait.o
clang --target=avr -mmcu=atmega328 -Icompat -I. -Ibitmaps -D__LGT8FX8P__ -DF_CPU=16000000UL -c runtime.S -o obj_new/runtime.o
clang --target=avr -mmcu=atmega328 -Icompat -I. -Ibitmaps -D__LGT8FX8P__ -DF_CPU=16000000UL -c crt_tc1.S -o obj_new/crt_tc1.o
ld.lld -T tc1.ld --gc-sections --no-check-sections -o firmware_baseline.elf obj_new/*.o
llvm-objcopy -O ihex -j .vectors -j .text -j .data firmware_baseline.elf firmware_baseline.hex
size firmware_baseline.elf
