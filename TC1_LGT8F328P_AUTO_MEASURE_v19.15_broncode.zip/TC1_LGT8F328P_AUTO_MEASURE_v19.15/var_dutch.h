/* ************************************************************************
 *
 *   language specific global variables: Dutch (ISO 8859-1)
 *
 *   based on var_english.h from Markus Reschke / Markus Frejek / Karl-Heinz Kuebbeler
 *
 * ************************************************************************ */


/*
 *  Dutch
 */

#if defined (UI_DUTCH)

  /*
   *  constant strings
   *  - stored in EEPROM/Flash
   */


  /* firmware */
  const unsigned char Tester_str[] MEM_TYPE = "M-Tester";


  /* common terms and texts */
  const unsigned char Probing_str[] MEM_TYPE = "Testen...";
  const unsigned char Timeout_str[] MEM_TYPE = "Timeout";
  const unsigned char Failed1_str[] MEM_TYPE = "Geen component";
  const unsigned char Failed2_str[] MEM_TYPE = "gevonden!";
  const unsigned char Done_str[] MEM_TYPE = "klaar!";
  const unsigned char Select_str[] MEM_TYPE = "Kies";
  const unsigned char Selftest_str[] MEM_TYPE = "Test";
  const unsigned char Adjustment_str[] MEM_TYPE = "Kalibratie";
  const unsigned char Save_str[] MEM_TYPE = "Opslaan";
  const unsigned char Load_str[] MEM_TYPE = "Laden";
  const unsigned char Show_str[] MEM_TYPE = "Toon Waarden";
  const unsigned char Remove_str[] MEM_TYPE = "Verwijderen";
  const unsigned char Create_str[] MEM_TYPE = "Aanmaken";
  const unsigned char ShortCircuit_str[] MEM_TYPE = "Kortsluiting!";
  const unsigned char DischargeFailed_str[] MEM_TYPE = "Batterij?";
  const unsigned char Error_str[] MEM_TYPE = "Fout!";
  const unsigned char Exit_str[] MEM_TYPE = "Terug";
  const unsigned char Checksum_str[] MEM_TYPE = "Controlesom";
  const unsigned char BJT_str[] MEM_TYPE = "BJT";
  const unsigned char Thyristor_str[] MEM_TYPE = "SCR";
  const unsigned char Triac_str[] MEM_TYPE = "Triac";
  const unsigned char PUT_str[] MEM_TYPE = "PUT";
  const unsigned char Bye_str[] MEM_TYPE = "Tot ziens!";


  /* units */
  const unsigned char Hertz_str[] MEM_TYPE = "Hz";


  /* options */
  #ifndef BAT_NONE
    const unsigned char Battery_str[] MEM_TYPE = "Bat";
    const unsigned char OK_str[] MEM_TYPE = "ok";
    const unsigned char Weak_str[] MEM_TYPE = "zwak";
    const unsigned char Low_str[] MEM_TYPE = "laag";
  #endif

  #ifdef BAT_EXT_UNMONITORED
    const unsigned char External_str[] MEM_TYPE = "ext";
  #endif

  #ifdef UI_KEY_HINTS
    const unsigned char Menu_or_Test_str[] MEM_TYPE = "<Menu Test>";
  #endif

  #if defined (SW_PWM_SIMPLE) || defined (SW_PWM_PLUS)
    const unsigned char PWM_str[] MEM_TYPE = "PWM";
  #endif

  #ifdef SW_SQUAREWAVE
    const unsigned char SquareWave_str[] MEM_TYPE = "Blokgolf";
  #endif

  #ifdef HW_ZENER
    const unsigned char Zener_str[] MEM_TYPE = "Zener";
    const unsigned char Min_str[] MEM_TYPE = "Min";
  #endif

  #ifdef HW_FREQ_COUNTER
    const unsigned char FreqCounter_str[] MEM_TYPE = "Freq. Teller";
  #endif

  #ifdef HW_FREQ_COUNTER_EXT
    const unsigned char CounterChannel_str[] MEM_TYPE = "Kan";
    const unsigned char FreqInput_str[] MEM_TYPE = "BNC";
    const unsigned char LF_Crystal_str[] MEM_TYPE = "LF kristal";
    const unsigned char HF_Crystal_str[] MEM_TYPE = "HF kristal";
  #endif

  #ifdef HW_EVENT_COUNTER
    const unsigned char EventCounter_str[] MEM_TYPE = "Gebeurtenisteller";
    const unsigned char Count_str[] MEM_TYPE = "Aantal";
    const unsigned char Time_str[] MEM_TYPE = "Tijd";
    const unsigned char Events_str[] MEM_TYPE = "Gebeurtenissen";
    const unsigned char Stop_str[] MEM_TYPE = "Stop";
  #endif

  #ifdef HW_LC_METER
    const unsigned char LC_Meter_str[] MEM_TYPE = "LC Meter";
    const unsigned char Adjusting_str[] MEM_TYPE = "kalibreren...";
  #endif

  #ifdef SW_ENCODER
    const unsigned char Encoder_str[] MEM_TYPE = "Draaiknop";
    const unsigned char TurnRight_str[] MEM_TYPE = "Draai rechtsom!";
  #endif

  #ifdef SW_CONTRAST
    const unsigned char Contrast_str[] MEM_TYPE = "Contrast";
  #endif

  #if defined (SW_IR_RECEIVER) || defined (HW_IR_RECEIVER)
    const unsigned char IR_Detector_str[] MEM_TYPE = "IR detector";
  #endif

  #ifdef SW_IR_TRANSMITTER
    const unsigned char IR_Transmitter_str[] MEM_TYPE = "IR AB";
    const unsigned char IR_Send_str[] MEM_TYPE = "verzenden...";
  #endif

  #ifdef SW_OPTO_COUPLER
    const unsigned char OptoCoupler_str[] MEM_TYPE = "Optokoppelaar";
    const unsigned char None_str[] MEM_TYPE = "Geen";
    const unsigned char CTR_str[] MEM_TYPE = "CTR";
  #endif

  #if defined (SW_OPTO_COUPLER) || defined (SW_DS18B20) || defined (SW_ONEWIRE_SCAN) || defined (HW_EVENT_COUNTER)
    const unsigned char Start_str[] MEM_TYPE = "Start";
  #endif

  #ifdef SW_UJT
    const unsigned char UJT_str[] MEM_TYPE = "UJT";
  #endif

  #ifdef SW_SERVO
    const unsigned char Servo_str[] MEM_TYPE = "Servo";
    const unsigned char Sweep_str[] MEM_TYPE = "<->";
  #endif

  #ifdef SW_CAP_LEAKAGE
    const unsigned char CapLeak_str[] MEM_TYPE = "Cap Lekkage";
    const unsigned char CapCharge_str[] MEM_TYPE = "Opladen";
    const unsigned char CapHigh_str[] MEM_TYPE = "Rl";
    const unsigned char CapLow_str[] MEM_TYPE = "Rh";
    const unsigned char CapDischarge_str[] MEM_TYPE = "Ontladen";
  #endif

  #ifdef SW_MONITOR_R
    const unsigned char Monitor_R_str[] MEM_TYPE = "R Monitor";
  #endif

  #ifdef SW_MONITOR_C
    const unsigned char Monitor_C_str[] MEM_TYPE = "C Monitor";
  #endif

  #ifdef SW_MONITOR_L
    const unsigned char Monitor_L_str[] MEM_TYPE = "L Monitor";
  #endif

  #ifdef SW_MONITOR_RCL
    const unsigned char Monitor_RCL_str[] MEM_TYPE = "RCL Monitor";
  #endif

  #ifdef SW_MONITOR_RL
    const unsigned char Monitor_RL_str[] MEM_TYPE = "RL Monitor";
  #endif

  #ifdef HW_TOUCH
    const unsigned char TouchSetup_str[] MEM_TYPE = "Touch Instellingen";
  #endif

  #ifdef SW_POWER_OFF
    const unsigned char PowerOff_str[] MEM_TYPE = "Uit";
  #endif

  #ifdef SW_ONEWIRE_SCAN
    const unsigned char OneWire_Scan_str[] MEM_TYPE = "OneWire Scan";
    const unsigned char Bus_str[] MEM_TYPE = "Bus";
  #endif

#endif


/* ************************************************************************
 *   EOF
 * ************************************************************************ */
