TC1 LGT8F328P COLD_BOOT_FIX_v5_NOMILLISLEEP

Based on v4 LCDTEST, which fixed the white-screen cold boot.

Change in v5:
- On LGT8F328P, MilliSleep() no longer uses Timer2/interrupt timing.
- All MilliSleep() calls use a simple 1 ms busy-wait loop.
- wdt_reset() is called every 1 ms so delays remain safe after the 2 s watchdog is enabled.
- Non-LGT builds retain the original Timer2 MilliSleep implementation.
- The proven v4 LCD cold-start sequence remains unchanged.
- Physical emulated EEPROM region 0x7800..0x7FFF is copied unchanged from the v4 combined image.

Purpose:
The v4 firmware cold-boots and displays the welcome screen, then hangs at the next MilliSleep(1500).
This version removes the remaining Timer2 dependency for LGT8F328P.
