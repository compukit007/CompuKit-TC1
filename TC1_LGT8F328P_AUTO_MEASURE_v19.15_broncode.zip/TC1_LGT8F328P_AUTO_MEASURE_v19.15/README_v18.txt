TC1 LGT8F328P AUTO_MEASURE v18 - ORIGINAL UI + AUTO IR
========================================================

Testversie gebaseerd op de originele transistor-tester-lgt328p broncode en de
hardwaremapping die op deze TC1 is bevestigd.

Wat in deze versie is aangepast
-------------------------------
- Gele M-Tester titelbalk met zwarte tekst, zonder permanente batterijwaarde.
- Tijdens de test: Testing... + Vbat=...V OK.
- Grote cyaan/blauwe ZIF-socket tekening tijdens testen en bij geen/onbekend onderdeel.
- Diode/LED-resultaat in de stijl van de originele tester:
  Diode, Uf, groot groen diodesymbool en gekleurde probe-blokken.
  Probe 1 = rood, probe 2 = blauw, probe 3 = geel.
  Bij meerdere diode-overgangen staat ook xN; het grote beeld toont de eerste overgang.
- De gewone grafische transistor/FET/SCR/TRIAC-symbolen blijven actief.
- Na een componententest blijft het resultaat staan en de IR-ontvanger op PD3 blijft luisteren.
- Een volledig geldig NEC- of Samsung-frame schakelt direct naar IR Decoder.
  Een korte druk op de afstandsbediening hoort dus voldoende te zijn.
- IR Decoder toont UserCode, DataCode, protocol en twee groene blokgolven.
- Het IR-scherm blijft staan totdat een nieuwe geldige IR-code binnenkomt of de testerknop wordt gebruikt.
- Testerknop: PD7.
- Accumeting: PC5.
- Auto-off: 180 seconden.
- Kalibratie (profiel 1), Optocoupler, ESR en inductiemeting blijven aanwezig.
- PUT, UJT en speciale Schottky-clamped-BJT herkenning zijn niet opgenomen in deze compacte build
  (zelfde ruimtebesparing als in de eerdere compacte versie).

Flashgeheugen
-------------
Programma-einde: 0x7774
Vrij tot de LGT EEPROM-zone op 0x7800: 139 bytes
De 11-byte standaard EEPROM/config is gespiegeld op 0x7800 en 0x7C00.

Bestanden
---------
TC1_LGT8F328P_AUTO_MEASURE_v18_ORIGINAL_UI_AUTO_IR_with_EEPROM.hex
  Aanbevolen voor een volledige testflash; bevat programma + EEPROM/config defaults.

TC1_LGT8F328P_AUTO_MEASURE_v18_ORIGINAL_UI_AUTO_IR_flash_only.hex
  Alleen het programma; bestaande EEPROM/config blijft ongemoeid.

Flashen (zelfde methode als v17)
--------------------------------
avrdude -p m328p -c stk500v1 -P COM3 -b 115200 -U flash:w:TC1_LGT8F328P_AUTO_MEASURE_v18_ORIGINAL_UI_AUTO_IR_with_EEPROM.hex:i

LET OP
------
Deze build is statisch gecontroleerd en compileert/linkt binnen de gereserveerde
programmaflash. Ik kan de echte TC1-hardware hier niet fysiek bedienen, dus behandel
v18 als testversie. Bewaar een werkende vorige HEX om terug te kunnen flashen.
