#include <stdint.h>
#include <stddef.h>
#include <avr/io.h>
#include <avr/interrupt.h>

size_t strlen(const char *s){ const char *p=s; while(*p) p++; return (size_t)(p-s); }
void *memset(void *d,int c,size_t n){ uint8_t *p=(uint8_t*)d; while(n--) *p++=(uint8_t)c; return d; }
void *memcpy(void *d,const void *s,size_t n){ uint8_t *dd=(uint8_t*)d; const uint8_t *ss=(const uint8_t*)s; while(n--) *dd++=*ss++; return d; }
char *strcpy(char *d,const char *s){ char *r=d; do{*d=*s; d++;}while(*s++); return r; }

static char *utoa_core(uint32_t v,char *s,uint8_t radix){
  char tmp[33]; uint8_t i=0,j=0;
  if(radix<2 || radix>16){s[0]=0; return s;}
  do { uint32_t q=v/(uint32_t)radix; uint8_t rem=(uint8_t)(v-q*(uint32_t)radix); tmp[i++]=(char)(rem<10?'0'+rem:'a'+rem-10); v=q; } while(v);
  while(i) s[j++]=tmp[--i]; s[j]=0; return s;
}
char *utoa(unsigned int v,char *s,int radix){ return utoa_core(v,s,(uint8_t)radix); }
char *ultoa(unsigned long v,char *s,int radix){ return utoa_core(v,s,(uint8_t)radix); }

#define EERE 0
#define EEPE 1
#define EEMPE 2
uint8_t eeprom_read_byte(const uint8_t *p){
  uintptr_t a=(uintptr_t)p;
  while(EECR & (1<<EEPE)){}
  EEARL=(uint8_t)a; EEARH=(uint8_t)(a>>8);
  EECR |= (1<<EERE);
  return EEDR;
}
uint16_t eeprom_read_word(const uint16_t *p){ uintptr_t a=(uintptr_t)p; uint16_t v=eeprom_read_byte((const uint8_t*)a); v|=(uint16_t)eeprom_read_byte((const uint8_t*)(a+1))<<8; return v; }
void eeprom_read_block(void *dst,const void *src,size_t n){ uint8_t *d=(uint8_t*)dst; uintptr_t a=(uintptr_t)src; while(n--)*d++=eeprom_read_byte((const uint8_t*)a++); }
void eeprom_write_byte(uint8_t *p,uint8_t v){
  uintptr_t a=(uintptr_t)p; while(EECR & (1<<EEPE)){}
  EEARL=(uint8_t)a; EEARH=(uint8_t)(a>>8); EEDR=v;
  uint8_t s=SREG; cli(); EECR=(1<<EEMPE); EECR=(1<<EEPE); SREG=s;
}
void eeprom_write_word(uint16_t *p,uint16_t v){ uintptr_t a=(uintptr_t)p; eeprom_write_byte((uint8_t*)a,(uint8_t)v); eeprom_write_byte((uint8_t*)(a+1),(uint8_t)(v>>8)); }
void eeprom_write_block(const void *src,void *dst,size_t n){ const uint8_t *s=(const uint8_t*)src; uintptr_t a=(uintptr_t)dst; while(n--)eeprom_write_byte((uint8_t*)a++,*s++); }

/* CRT compatibility symbols; reset code performs this work. */
void __do_copy_data(void){}
void __do_clear_bss(void){}
