/* TC1 original-style compact UI additions for the LGT8F328P build. */
#include "config.h"
#include "common.h"
#include "variables.h"
#include "functions.h"
#include "colors.h"
#include <avr/pgmspace.h>

#ifdef LCD_ST7735

extern uint16_t X_Start;
extern uint16_t X_End;
extern uint16_t Y_Start;
extern uint16_t Y_End;
extern void LCD_Box(uint16_t Color);

/* size of the body font (see config_lgt8f328p.h) */
#ifndef TC1_FONT_W
  #define TC1_FONT_W  10
#endif
#define TC1_FONT_H  16

/* all UI strings, per language */
#include "tc1_lang.h"

/* short local names */
#define TxtTesting      TC1_TxtTesting
#define TxtVbat         TC1_TxtVbat
#define TxtNoBat        TC1_TxtNoBat
#define TxtDiode        TC1_TxtDiode
#define TxtCap          TC1_TxtCap
#define TxtRes          TC1_TxtRes
#define Txt2Res         TC1_Txt2Res
#define TxtCoil         TC1_TxtCoil
#define TxtESR          TC1_TxtESR
#define TxtLeak         TC1_TxtLeak
#define TxtNo1          TC1_TxtNo1
#define TxtNo2          TC1_TxtNo2
#define TxtIR           TC1_TxtIR
#define TxtUser         TC1_TxtUser
#define TxtData         TC1_TxtData
#define TxtSamsung      TC1_TxtSamsung
#define TxtNEC          TC1_TxtNEC
#define TxtShort1       TC1_TxtShort1
#define TxtShort2       TC1_TxtShort2
#define TxtOpen1        TC1_TxtOpen1
#define TxtOpen2        TC1_TxtOpen2
#define TxtZener        TC1_TxtZener
#define TxtZenerHint    TC1_TxtZenerHint
#define TxtESRTitle     TC1_TxtESRTitle
#define TxtESRWarn1     TC1_TxtESRWarn1
#define TxtESRWarn2     TC1_TxtESRWarn2
#define TxtESRWarn3     TC1_TxtESRWarn3
#define TxtESRPins      TC1_TxtESRPins
#define TxtVoltage      TC1_TxtVoltage
#define TxtMenu1        TC1_TxtMenu1
#define TxtMenu2        TC1_TxtMenu2
#define TxtMenu3        TC1_TxtMenu3
#define TxtMenu4        TC1_TxtMenu4
#define TxtMenu5        TC1_TxtMenu5
#define TxtMenu6        TC1_TxtMenu6
#define TxtHint1        TC1_TxtHint1

/* main menu (large) */
#define TC1_MENU_N  6

static void TC1_PutsP(uint8_t x, uint8_t y, const unsigned char *p)
{
  uint8_t c;
  LCD_CharPos(x, y);
  while ((c = pgm_read_byte(p++)) != 0) LCD_Char(c);
}

static void TC1_Rect(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1, uint16_t color)
{
  X_Start = x0; X_End = x1; Y_Start = y0; Y_End = y1;
  LCD_Box(color);
}

/* Tiny 3x5 digits used inside the colored probe blocks. */
static void TC1_Digit(uint8_t digit, uint8_t x, uint8_t y, uint8_t scale, uint16_t color)
{
  uint8_t row, col, bits;
  static const uint8_t D1[5] PROGMEM = {2,6,2,2,7};
  static const uint8_t D2[5] PROGMEM = {7,1,7,4,7};
  static const uint8_t D3[5] PROGMEM = {7,1,7,1,7};
  const uint8_t *table = D1;
  if (digit == 2) table = D2;
  else if (digit == 3) table = D3;

  for (row = 0; row < 5; row++)
  {
    bits = pgm_read_byte(table + row);
    for (col = 0; col < 3; col++)
    {
      if (bits & (1 << (2-col)))
      {
        TC1_Rect(x + col*scale, y + row*scale,
                 x + col*scale + scale-1, y + row*scale + scale-1, color);
      }
    }
  }
}



void TC1_DrawZIF(void)
{
  uint8_t i;
  uint8_t x = 29;

  /* Compact original-style ZIF socket: cyan body, black holes and lever. */
  TC1_Rect(22, 72, 139, 118, COLOR_CYAN);
  TC1_Rect(8, 78, 14, 108, COLOR_CYAN);
  TC1_Rect(14, 82, 22, 88, COLOR_CYAN);

  for (i = 0; i < 7; i++)
  {
    TC1_Rect(x, 78, x+8, 88, COLOR_BLACK);
    TC1_Rect(x, 102, x+8, 112, COLOR_BLACK);
    x += 15;
  }

  /* center channel */
  TC1_Rect(27, 92, 134, 98, COLOR_BLACK);
}

/*
 *  state of charge of the Li-ion cell in % (0-100)
 *  - simple discharge curve, linear interpolation between the points
 */

static uint8_t TC1_BatPercent(uint16_t mV)
{
  static const uint16_t Volt[7] PROGMEM = {4200, 4000, 3850, 3750, 3650, 3500, 3300};
  static const uint8_t  Pct[7]  PROGMEM = {100,  80,   60,   40,   20,   5,    0};
  uint8_t  i;
  uint16_t V_hi, V_lo;
  uint8_t  P_hi, P_lo;

  if (mV >= 4200) return 100;
  if (mV <= 3300) return 0;

  for (i = 1; i < 7; i++)
  {
    V_lo = pgm_read_word(&Volt[i]);
    if (mV >= V_lo)                     /* between point i-1 and i */
    {
      V_hi = pgm_read_word(&Volt[i - 1]);
      P_hi = pgm_read_byte(&Pct[i - 1]);
      P_lo = pgm_read_byte(&Pct[i]);
      return P_lo + (uint8_t)(((uint32_t)(mV - V_lo) * (P_hi - P_lo)) / (V_hi - V_lo));
    }
  }
  return 0;
}

void TC1_ShowTesting(uint16_t Vbat)
{
  uint16_t saved = UI.PenColor;
  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(4, 2, TxtTesting);

#ifndef BAT_NONE
  TC1_PutsP(2, 3, TxtVbat);
  LCD_CharPos(7, 3);
  if (Vbat < 1000)                      /* no battery (powered via USB/ISP) */
  {
    UI.PenColor = COLOR_YELLOW;
    TC1_PutsP(7, 3, TxtNoBat);          /* geen accu */
  }
  else
  {
    uint8_t Pct = TC1_BatPercent(Vbat);

    Display_Value(Vbat / 10, -2, 'V');
    Display_Space();
    if (Pct > 40)      UI.PenColor = COLOR_GREEN;
    else if (Pct > 20) UI.PenColor = COLOR_YELLOW;
    else               UI.PenColor = COLOR_RED;
    Display_Value(Pct, 0, '%');
  }
#endif

  TC1_DrawZIF();
  UI.PenColor = saved;
}

/*
 *  calibration: tell user to create (Mode 1) or remove (Mode 0) the
 *  short circuit between probes 1, 2 and 3
 *  - all ZIF holes are shown in their probe color, any 1/2/3 hole will do
 */

void TC1_ShowShortInstr(uint8_t Mode)
{
  uint16_t saved = UI.PenColor;

  LCD_Clear();
  UI.PenColor = COLOR_WHITE;
  if (Mode)
  {
    TC1_PutsP(3, 2, TxtShort1);         /* Verbind pin */
    UI.PenColor = COLOR_YELLOW;
    TC1_PutsP(4, 3, TxtShort2);         /* 1, 2 en 3 */
  }
  else
  {
    TC1_PutsP(3, 2, TxtOpen1);          /* Verwijder de */
    TC1_PutsP(4, 3, TxtOpen2);          /* verbinding */
  }

  TC1_DrawZIF();

  if (Mode)
  {
    /* color every ZIF hole by its probe: 1 red, 2 blue, 3 yellow
       top row:    1 2 3 1 2 3 2
       bottom row: K A A 1 2 3 3  (K/A stay black) */
    static const uint8_t Top[7] PROGMEM = {1, 2, 3, 1, 2, 3, 2};
    static const uint8_t Bottom[7] PROGMEM = {0, 0, 0, 1, 2, 3, 3};
    uint8_t i, p, x = 29;
    uint16_t Color;

    for (i = 0; i < 7; i++)
    {
      p = pgm_read_byte(&Top[i]);
      Color = (p == 1) ? COLOR_RED : ((p == 2) ? COLOR_BLUE : COLOR_YELLOW);
      TC1_Rect(x, 78, x + 8, 88, Color);

      p = pgm_read_byte(&Bottom[i]);
      if (p)
      {
        Color = (p == 1) ? COLOR_RED : ((p == 2) ? COLOR_BLUE : COLOR_YELLOW);
        TC1_Rect(x, 102, x + 8, 112, Color);
      }
      x += 15;
    }
  }

  UI.PenColor = saved;
}

/*
 *  Zener test: title, exit hint and ZIF picture with the K (red)
 *  and A (blue) holes of the bottom row
 */

void TC1_ShowZenerHead(void)
{
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(2, 2, TxtZener);            /* Zenertest */
  UI.PenColor = COLOR_CYAN;
  TC1_PutsP(2, 3, TxtZenerHint);        /* 2x kort=terug */
  TC1_DrawZIF();
  TC1_Rect(29, 102, 37, 112, COLOR_RED);    /* K */
  TC1_Rect(44, 102, 52, 112, COLOR_BLUE);   /* A */
  TC1_Rect(59, 102, 67, 112, COLOR_BLUE);   /* A */
  UI.PenColor = saved;
}

/*
 *  ESR tool: title, safety warning and probes used
 */

void TC1_ShowESRHead(void)
{
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(1, 2, TxtESRTitle);         /* ESR-meting */
  UI.PenColor = COLOR_RED;
  TC1_PutsP(1, 3, TxtESRWarn1);         /* Print uit en */
  TC1_PutsP(1, 4, TxtESRWarn2);         /* condensator */
  TC1_PutsP(1, 5, TxtESRWarn3);         /* eerst ontladen! */
  UI.PenColor = COLOR_CYAN;
  TC1_PutsP(1, 6, TxtESRPins);          /* pin1=+  pin3=- */
  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(1, 8, TxtZenerHint);        /* 2x kort=terug */
  LCD_CharPos(1, 7);                    /* result line */
  Display_Char('-');
  UI.PenColor = saved;
}

/*
 *  start screen of a tool: title plus key hints
 *  (1x short = start, 2x short = back)
 */

void TC1_ShowToolStart(const unsigned char *Title)
{
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(1, 2, Title);
  UI.PenColor = COLOR_CYAN;
  TC1_PutsP(1, 4, TC1_TxtStartHint);    /* 1x kort=start */
  TC1_PutsP(1, 5, TxtZenerHint);        /* 2x kort=terug */
  UI.PenColor = saved;
}

/* ESR tool: still charged cap detected */
void TC1_ShowVoltageWarning(void)
{
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_RED;
  TC1_PutsP(1, 7, TxtVoltage);          /* Spanning! */
  UI.PenColor = saved;
}

void TC1_ShowFailOriginal(void)
{
  uint16_t saved = UI.PenColor;
  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(3, 2, TxtNo1);
  TC1_PutsP(1, 3, TxtNo2);
  UI.PenColor = COLOR_GREEN;
  LCD_CharPos(8, 4);
  LCD_Char('?');
  TC1_DrawZIF();
  UI.PenColor = saved;
}

/*
 *  colored pin blocks (1 red, 2 blue, 3 yellow) with black probe number,
 *  plus the wires towards the component symbol in the middle
 *  - Left/Right: probe IDs (0-2)
 */

/*
 *  probe number as small colored block with black digit at a
 *  character position (used next to the 3-pin semiconductor symbols)
 */

void TC1_ProbeBlock(uint8_t CharX, uint8_t CharY, uint8_t Probe)
{
  uint8_t x = (CharX - 1) * TC1_FONT_W;
  uint8_t y = (CharY - 1) * TC1_FONT_H;

  TC1_Rect(x, y, x + TC1_FONT_W - 1, y + TC1_FONT_H - 1,
           (Probe == 0) ? COLOR_RED : ((Probe == 1) ? COLOR_BLUE : COLOR_YELLOW));
  /* full size font digit in black for readability */
  TC1_BigChar('1' + Probe, x, y, 1, COLOR_BLACK);
}


/*
 *  resistance with a clear prefix: 1000 Ohms and up as k/M
 *  (Display_Value() shows up to 4 digits without prefix, e.g. 1013)
 */

static void TC1_ValueR(uint32_t Value, int8_t Scale)
{
  if ((Value >= 1000) && (((Scale + 15) % 3) == 0))
  {
    Value = (Value + 5) / 10;          /* one digit less, next prefix */
    Scale++;
  }
  Display_Value(Value, Scale, LCD_CHAR_OMEGA);
}

/* one 24x24 pin block at x (y 72-95) with black probe number */
static void TC1_Block(uint8_t Pin, uint8_t x)
{
  TC1_Rect(x, 72, x + 23, 95,
           (Pin == 0) ? COLOR_RED : ((Pin == 1) ? COLOR_BLUE : COLOR_YELLOW));
  TC1_Digit(Pin + 1, x + 9, 79, 2, COLOR_BLACK);
}

static void TC1_PinBlocks(uint8_t Left, uint8_t Right)
{
  TC1_Block(Left, 16);
  TC1_Block(Right, 120);

  /* wires */
  TC1_Rect(40, 83, 68, 85, COLOR_STEEL_BLUE);
  TC1_Rect(91, 83, 119, 85, COLOR_STEEL_BLUE);
}

/* resistor symbol: green outlined box from x0 to x1 (y 77-91) */
static void TC1_ResistorSym(uint8_t x0, uint8_t x1)
{
  TC1_Rect(x0, 77, x1, 91, COLOR_GREEN);
  TC1_Rect(x0 + 2, 79, x1 - 2, 89, COLOR_BACKGROUND);
}

void TC1_ShowSingleDiode(void)
{
  Diode_Type *d = &Diodes[0];
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(2, 2, TxtDiode);
  if (Check.Diodes > 1)
  {
    Display_Space();
    LCD_Char('x');
    LCD_Char('0' + Check.Diodes);
  }
  LCD_CharPos(2, 3);
  LCD_Char('U'); LCD_Char('f'); LCD_Char('=');
  Display_Value(d->V_f, -3, 'V');

  /* pin blocks and wires, always drawn anode-left/cathode-right */
  TC1_PinBlocks(d->A, d->C);

  /* large diode */
  TC1_Rect(70, 76, 72, 92, COLOR_GREEN);
  TC1_Rect(73, 78, 76, 90, COLOR_GREEN);
  TC1_Rect(77, 80, 80, 88, COLOR_GREEN);
  TC1_Rect(81, 82, 84, 86, COLOR_GREEN);
  TC1_Rect(88, 76, 90, 92, COLOR_GREEN);

  UI.PenColor = saved;
}


/*
 *  resistor / inductor result in the same style as the diode
 *  - R2: second resistor (common pin Pin) or NULL for a single one
 *  - IsL: single resistor is an inductor (global Inductor is valid)
 */

void TC1_ShowResistor(Resistor_Type *R1, Resistor_Type *R2, uint8_t Pin, uint8_t IsL)
{
  uint16_t saved = UI.PenColor;
  uint8_t  a, b, i;

  UI.PenColor = COLOR_WHITE;

  if (R2 == NULL)                            /* single resistor */
  {
    a = R1->A;
    b = R1->B;
    if (a > b) { i = a; a = b; b = i; }      /* lower probe left */

    TC1_PutsP(2, 2, IsL ? TxtCoil : TxtRes); /* Spoel / Weerstand */
    LCD_CharPos(2, 3);
    LCD_Char('R'); LCD_Char('=');
    TC1_ValueR(R1->Value, R1->Scale);

    TC1_PinBlocks(a, b);

    #ifdef SW_INDUCTOR
    if (IsL)                                 /* inductor */
    {
      LCD_CharPos(2, 4);
      LCD_Char('L'); LCD_Char('=');
      Display_Value(Inductor.Value, Inductor.Scale, 'H');

      /* coil: 4 loops on the wire */
      TC1_Rect(69, 83, 90, 85, COLOR_STEEL_BLUE);
      for (i = 0; i < 4; i++)
      {
        TC1_Rect(62 + (i * 9), 76, 69 + (i * 9), 78, COLOR_GREEN);
        TC1_Rect(62 + (i * 9), 76, 63 + (i * 9), 84, COLOR_GREEN);
        TC1_Rect(68 + (i * 9), 76, 69 + (i * 9), 84, COLOR_GREEN);
      }
    }
    else
    #endif
    {
      TC1_ResistorSym(62, 97);
    }
  }
  else                                       /* two resistors, common pin */
  {
    TC1_PutsP(2, 2, Txt2Res);                /* 2 weerstanden */
    LCD_CharPos(2, 3);
    LCD_Char('R'); LCD_Char('1'); LCD_Char('=');
    TC1_ValueR(R1->Value, R1->Scale);
    LCD_CharPos(2, 4);
    LCD_Char('R'); LCD_Char('2'); LCD_Char('=');
    TC1_ValueR(R2->Value, R2->Scale);

    /* outer pins and common pin in the middle */
    a = (R1->A != Pin) ? R1->A : R1->B;
    b = (R2->A != Pin) ? R2->A : R2->B;
    TC1_Rect(28, 83, 131, 85, COLOR_STEEL_BLUE);  /* wire */
    TC1_Block(a, 4);
    TC1_Block(Pin, 68);
    TC1_Block(b, 132);
    TC1_ResistorSym(34, 61);                  /* R1 */
    TC1_ResistorSym(98, 125);                 /* R2 */
  }

  UI.PenColor = saved;
}


/*
 *  capacitor result in the same style as the diode
 *  - ESR: in 0.01 Ohms, UINT16_MAX if not measured
 */

void TC1_ShowCapacitor(Capacitor_Type *Cap, uint16_t ESR)
{
  uint16_t saved = UI.PenColor;

  UI.PenColor = COLOR_WHITE;
  TC1_PutsP(2, 2, TxtCap);                   /* Condensator */
  LCD_CharPos(2, 3);
  LCD_Char('C'); LCD_Char('=');
  Display_Value(Cap->Value, Cap->Scale, 'F');

  if (ESR < UINT16_MAX)                      /* ESR measured */
  {
    TC1_PutsP(2, 4, TxtESR);
    Display_Value(ESR, -2, LCD_CHAR_OMEGA);
  }

  if (Cap->I_leak > 0)                       /* leakage current */
  {
    TC1_PutsP(2, 7, TxtLeak);
    Display_Value(Cap->I_leak, -8, 'A');     /* in 10nA */
  }

  /* pin blocks, wires and capacitor plates */
  TC1_PinBlocks(Cap->A, Cap->B);
  TC1_Rect(69, 83, 74, 85, COLOR_STEEL_BLUE);     /* close wire gap */
  TC1_Rect(85, 83, 90, 85, COLOR_STEEL_BLUE);
  TC1_Rect(75, 74, 78, 94, COLOR_GREEN);          /* plate 1 */
  TC1_Rect(82, 74, 85, 94, COLOR_GREEN);          /* plate 2 */

  UI.PenColor = saved;
}

/* enlarged text from flash at pixel position */
static void TC1_BigStrP(const unsigned char *p, uint8_t x, uint8_t y, uint8_t scale, uint16_t color)
{
  uint8_t c;
  while ((c = pgm_read_byte(p++)) != 0)
  {
    TC1_BigChar(c, x, y, scale, color);
    x += TC1_FONT_W * scale;
  }
}

/* enlarged 4 digit hex value at pixel position */
static void TC1_BigHex16(uint16_t v, uint8_t x, uint8_t y, uint8_t scale, uint16_t color)
{
  uint8_t i, d;
  for (i = 0; i < 4; i++)
  {
    d = (uint8_t)(v >> 12);
    TC1_BigChar((d < 10) ? ('0' + d) : ('A' - 10 + d), x, y, scale, color);
    x += TC1_FONT_W * scale;
    v <<= 4;
  }
}

/* bit stream as square wave: 16 bits, 9 pixels per bit, 14 pixels high */
static void TC1_Wave16(uint16_t value, uint8_t y)
{
  uint8_t i;
  uint8_t old = 0xff;
  uint8_t level;
  uint8_t x = 8;

  for (i = 0; i < 16; i++)
  {
    /* Show the transmitted-style bit stream from low bit to high bit. */
    level = (value >> i) & 1;
    if (old != 0xff && old != level)
      TC1_Rect(x-1, y, x, y+13, COLOR_GREEN);
    TC1_Rect(x, level ? y : y+12, x+8, level ? y+1 : y+13, COLOR_GREEN);
    old = level;
    x += 9;
  }
}

/*
 *  large main menu: 4 items, selected item highlighted
 *  - short key press: next item
 *  - long key press: select item
 *
 *  returns:
 *  - index of selected item (0 to TC1_MENU_N - 1)
 */

uint8_t TC1_MainMenu(void)
{
  const unsigned char *Items[TC1_MENU_N];
  const unsigned char *p;
  uint8_t           Sel = 0;
  uint8_t           Redraw = 1;
  uint8_t           i, Len, Key;
  uint8_t           y;

  Items[0] = TxtMenu1;
  Items[1] = TxtMenu2;
  Items[2] = TxtMenu3;
  Items[3] = TxtMenu4;
  Items[4] = TxtMenu5;
  Items[5] = TxtMenu6;

  LCD_Clear();
  TC1_BigStrP(TxtHint1, 15, 112, 1, COLOR_WHITE);   /* y 112-127 */

  for (;;)
  {
    if (Redraw)
    {
      for (i = 0; i < TC1_MENU_N; i++)
      {
        y = 16 + (i * 16);                 /* rows 16 ... 96 */
        /* highlight bar for selected item */
        TC1_Rect(0, y, 159, y + 15, (i == Sel) ? COLOR_BLUE : COLOR_BACKGROUND);
        /* centered text */
        p = Items[i];
        Len = 0;
        while (pgm_read_byte(p++) != 0) Len++;
        TC1_BigStrP(Items[i], (160 - (Len * TC1_FONT_W)) / 2, y, 1,
                    (i == Sel) ? COLOR_YELLOW : COLOR_WHITE);
      }
      Redraw = 0;
    }

    Key = TestKey(0, CHECK_BAT);         /* wait for key */
    if (Key == KEY_SHORT)                /* next item */
    {
      Sel++;
      if (Sel >= TC1_MENU_N) Sel = 0;
      Redraw = 1;
    }
    else if (Key == KEY_LONG)            /* select item */
    {
      break;
    }
  }

  LCD_Clear();
  return Sel;
}


/* IR activity lamp in the title bar: red while IR is received,
   back to the yellow title bar color when switched off */
void TC1_ShowIRActivity(uint8_t On)
{
  TC1_Rect(148, 5, 153, 10, On ? COLOR_RED : COLOR_YELLOW);
}


void TC1_ShowIR(uint8_t Protocol, uint16_t UserCode, uint16_t DataCode)
{
  uint16_t saved = UI.PenColor;
  LCD_Clear();
  UI.LineMode = LINE_KEEP;
  UI.PenColor = COLOR_WHITE;

  /* layout for 160x128 with 10x16 font: title bar 0-15 */
  TC1_BigStrP(TxtIR, 30, 18, 1, COLOR_WHITE);            /* IR-decoder */

  TC1_Wave16(UserCode, 36);                              /* y 36-49 */
  TC1_BigStrP(TxtUser, 4, 54, 1, COLOR_WHITE);           /* Adres */
  TC1_BigHex16(UserCode, 116, 54, 1, COLOR_YELLOW);      /* y 54-69 */

  TC1_Wave16(DataCode, 72);                              /* y 72-85 */
  TC1_BigStrP(TxtData, 4, 90, 1, COLOR_WHITE);           /* Commando */
  TC1_BigHex16(DataCode, 116, 90, 1, COLOR_YELLOW);      /* y 90-105 */

  /* protocol, centered: y 110-125 */
  if (Protocol == 2) TC1_BigStrP(TxtSamsung, 45, 110, 1, COLOR_CYAN);
  else               TC1_BigStrP(TxtNEC, 65, 110, 1, COLOR_CYAN);
  UI.PenColor = saved;
}

#endif
