TC1 LGT8F328P MEASURE DIAG v1

Based on working v7 cold-boot/LCD setup.
Confirmed TC1 REV1A mapping used:
 PB0/RL1 -> TP1 via 680R
 PB1/RH1 -> TP1 via 470k
 PB2/RL2 -> TP2 via 680R
 PB3/RH2 -> TP2 via 470k
 PB4/RL3 -> TP3 via 680R
 PB5/RH3 -> TP3 via 470k
 PC0/PC1/PC2 = TP1/TP2/TP3 ADC
 PC5 = battery ADC
 PD7 = TEST key electrical level

The diagnostic cycles every 2 seconds:
 DIAG OPEN -> PB0 HIGH -> PB1 HIGH -> ... -> PB5 HIGH
For PB0/PB1 expect TP1 close to 1023.
For PB2/PB3 expect TP2 close to 1023.
For PB4/PB5 expect TP3 close to 1023.
KEY shows the raw PD7 logic level. BAT shows raw ADC5.

First test with the ZIF socket/test leads EMPTY.
